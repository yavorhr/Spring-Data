package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;

import javax.validation.constraints.Size;

public class ConstellationSeedDto {

    @Expose
    private String name;
    @Expose
    private String description;

    @Size(min = 3, max = 20)
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Size(min = 5)
    public String getDescription() {
        return description;
    }

    public ConstellationSeedDto setDescription(String description) {
        this.description = description;
        return this;
    }
}
