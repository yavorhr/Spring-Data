package softuni.exam.service;

import softuni.exam.models.entity.Astronomer;
import softuni.exam.models.entity.Star;

import java.io.IOException;

public interface StarService {

    boolean areImported();

    String readStarsFileContent() throws IOException;
	
	String importStars() throws IOException;

    Star findStarById(Long cityId);

    void addAndSaveAddedStar(Star star, Astronomer astronomer);

    String exportStars();
}
