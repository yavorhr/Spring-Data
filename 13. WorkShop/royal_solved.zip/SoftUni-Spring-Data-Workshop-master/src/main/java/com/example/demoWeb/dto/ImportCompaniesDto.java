package com.example.demoWeb.dto;

public class ImportCompaniesDto {

    private String companies;

    public String getCompanies() {
        return companies;
    }

    public void setCompanies(String companies) {
        this.companies = companies;
    }
}
