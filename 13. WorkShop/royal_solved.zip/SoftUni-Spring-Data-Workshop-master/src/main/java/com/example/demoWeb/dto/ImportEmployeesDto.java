package com.example.demoWeb.dto;

public class ImportEmployeesDto {

    private String employees;

    public String getEmployees() {
        return employees;
    }

    public void setEmployees(String employees) {
        this.employees = employees;
    }
}
