package softuni.exam.models.dto;

import com.google.gson.annotations.Expose;
import softuni.exam.models.entity.enums.StarType;

import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

public class StarSeedDto {

    @Expose
    private String name;
    @Expose
    private Double lightYears;
    @Expose
    private String description;
    @Expose
    private StarType starType;
    @Expose
    private Long constellation;

    @Size(min = 2,max = 30)
    public String getName() {
        return name;
    }

    public StarSeedDto setName(String name) {
        this.name = name;
        return this;
    }

    @Positive
    public Double getLightYears() {
        return lightYears;
    }

    public StarSeedDto setLightYears(Double lightYears) {
        this.lightYears = lightYears;
        return this;
    }

    public StarType getStarType() {
        return starType;
    }

    public StarSeedDto setStarType(StarType starType) {
        this.starType = starType;
        return this;
    }

    @Size(min = 6)
    public String getDescription() {
        return description;
    }

    public StarSeedDto setDescription(String description) {
        this.description = description;
        return this;
    }

    public Long getConstellation() {
        return constellation;
    }

    public StarSeedDto setConstellation(Long constellation) {
        this.constellation = constellation;
        return this;
    }
}
