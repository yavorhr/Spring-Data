package softuni.exam.service.impl;

// TODO: Implement all methods
public class BorrowingRecordsServiceImpl {

}
