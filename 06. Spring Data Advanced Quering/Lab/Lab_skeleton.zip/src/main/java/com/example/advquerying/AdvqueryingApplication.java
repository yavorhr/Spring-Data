package com.example.advquerying;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvqueryingApplication {

    public static void main(String[] args) {
        SpringApplication.run(AdvqueryingApplication.class, args);
    }

}
