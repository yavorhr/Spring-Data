package com.example.demoWeb.dto;

public class ImportProjectsDto {

    private String projects;

    public String getProjects() {
        return projects;
    }

    public void setProjects(String projects) {
        this.projects = projects;
    }
}
